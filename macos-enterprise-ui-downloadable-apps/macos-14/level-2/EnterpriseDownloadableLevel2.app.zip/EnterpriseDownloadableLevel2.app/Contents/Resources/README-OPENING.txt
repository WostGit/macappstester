This app is ad-hoc signed, but not Apple-notarized.
If macOS reports it as damaged after download, run:
  xattr -dr com.apple.quarantine "EnterpriseDownloadableLevel2.app"
  open "EnterpriseDownloadableLevel2.app"
