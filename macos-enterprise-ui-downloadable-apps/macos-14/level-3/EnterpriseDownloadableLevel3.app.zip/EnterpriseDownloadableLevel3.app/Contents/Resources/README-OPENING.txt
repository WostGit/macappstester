This app is ad-hoc signed, but not Apple-notarized.
If macOS reports it as damaged after download, run:
  xattr -dr com.apple.quarantine "EnterpriseDownloadableLevel3.app"
  open "EnterpriseDownloadableLevel3.app"
