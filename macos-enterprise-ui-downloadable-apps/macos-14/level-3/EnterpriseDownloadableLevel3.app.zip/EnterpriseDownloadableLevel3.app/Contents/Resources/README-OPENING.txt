This app is ad-hoc signed, but not Apple-notarized.
If macOS reports it as damaged after download, run:
  xattr -dr com.apple.quarantine "EnterpriseDownloadableLevel3.app"
  open "EnterpriseDownloadableLevel3.app"

Activity Monitor comparison:
  1. Open this app.
  2. Open Activity Monitor.
  3. Search for EnterpriseDownloadableApp or the PID shown in the app title/status line.
  4. Compare % CPU and Memory. Values should be close, but may differ slightly because Activity Monitor and this app sample on different one-second boundaries.
