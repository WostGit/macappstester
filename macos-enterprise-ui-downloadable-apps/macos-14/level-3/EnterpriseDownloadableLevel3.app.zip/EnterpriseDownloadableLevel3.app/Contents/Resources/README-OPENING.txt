This test app is ad-hoc signed, but it is not notarized with an Apple Developer ID.

If macOS says the app is damaged or cannot be opened after download, remove the download quarantine attribute:

  xattr -dr com.apple.quarantine "EnterpriseDownloadableLevel3.app"
  open "EnterpriseDownloadableLevel3.app"

This is expected for unsigned/notarization-free test builds downloaded from GitHub.
